package com.example.demoapp.service;

import com.example.demoapp.model.Deal;
import com.example.demoapp.repository.DealRepository;
import com.example.demoapp.request.DealRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Time;
import java.sql.Timestamp;

@Component
public class DealService implements IDealService {

    @Autowired
    DealRepository dealRepository;

    @Override
    public Deal createDeal(final DealRequest dealRequest) {
        final Deal deal = setFields(dealRequest);
        if(deal == null)
        {
            deal.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            dealRepository.save(deal);
        }
        return deal;
    }

    @Override
    public Deal updateDeal(Deal deal, final DealRequest dealRequest) {

        deal.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        dealRepository.save(deal);
        return deal;
    }

    private Deal setFields(final DealRequest dealRequest){
        final Deal deal = new Deal();
        deal.setProductCode(dealRequest.getProductCode());
        deal.setProductCount(dealRequest.getProductCount());
        deal.setProductPrice(dealRequest.getProductPrice());
        deal.setSellerId(dealRequest.getSellerId());
        deal.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        return deal;
    }
}
