package com.example.demoapp.model;

public class User {

}

/*

User :
{
	id : String (PK)
	name : String,
	role : String
}
 */