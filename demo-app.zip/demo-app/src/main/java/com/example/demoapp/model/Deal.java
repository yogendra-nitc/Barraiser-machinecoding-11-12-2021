package com.example.demoapp.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Document(collation = "deals")
public class Deal {

    private String id;

    private String productCode;

    private Integer productCount;

    private Integer productPrice;

    private Date startAt;

    private Date endAt;

    private String sellerId;

    private List<String> userIds;

    private Date createdAt;
    private Date updatedAt;
}


/*
	id : String, (PK)
	product_code : String,
	product_count : Number,
	product_price : Number,
	start_at : Timestamp,
	end_at : Timestamp,
	seller_id : String,
	user_id : List<String>

	created_at : Timestamp
	updated_ate : Timestamp
 */
