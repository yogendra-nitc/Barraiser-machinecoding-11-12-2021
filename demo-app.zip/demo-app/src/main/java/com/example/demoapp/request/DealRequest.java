package com.example.demoapp.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
public class DealRequest {

    private String id;

    private String productCode;

    private Integer productCount;

    private Integer productPrice;

    private Date startAt;

    private Date endAt;

    private String sellerId;

}
