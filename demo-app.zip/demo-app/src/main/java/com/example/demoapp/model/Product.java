package com.example.demoapp.model;

import java.util.Date;

public class Product {
    private String id;

    private String name;

    private String code;

    private String description;

    private Date createdAt;
    private Date updatedAt;

}


/*
product {
	id : String (PK)
	name : String
	code : String
	desc : String
	count : Number
}
 */