package com.example.demoapp.controller;

import com.example.demoapp.model.Deal;
import com.example.demoapp.repository.DealRepository;
import com.example.demoapp.request.DealRequest;
import com.example.demoapp.service.DealService;
import com.example.demoapp.service.IDealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/deals")
public class DealController {
    @Autowired
    private IDealService dealService;

    @Autowired
    private DealRepository dealRepository;

//    @Value(value = "${test.value}")
//    private String testValue;

    @PostMapping("/")
    public ResponseEntity<?> CreateDeal(@RequestParam DealRequest dealRequest) {
        if(dealRequest == null){
            return new ResponseEntity<>(String.format("Request data required"), HttpStatus.BAD_REQUEST);
        }
        dealService.createDeal(dealRequest);
        return null;
    }

    @PutMapping("/")
    public ResponseEntity<?> updateDeal(@RequestParam DealRequest dealRequest) {
        if(dealRequest == null && dealRequest.getId() == null){
            return new ResponseEntity<>(String.format("Request data required"), HttpStatus.BAD_REQUEST);
        }
        Deal deal = dealRepository.findById(dealRequest.getId());
        dealService.updateDeal(deal,dealRequest);
        return null;
    }

    @PostMapping("/claim")
    public ResponseEntity<?> claimDeal(){
        return null;
    }
}
