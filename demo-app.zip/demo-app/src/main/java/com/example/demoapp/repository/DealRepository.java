package com.example.demoapp.repository;

import com.example.demoapp.model.Deal;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
@Repository
public interface DealRepository extends MongoRepository<Deal, String> {

}
