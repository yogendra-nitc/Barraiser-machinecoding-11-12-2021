package com.example.demoapp.service;

import com.example.demoapp.model.Deal;
import com.example.demoapp.request.DealRequest;

public interface IDealService {

    Deal createDeal(final DealRequest dealRequest);

    //TODO response can be customised later

    Deal updateDeal(Deal deal, final DealRequest dealRequest);
}
